import React, { useEffect, useState } from "react";
import { Play, Plus, Search, HelpCircle, LogOut, Code, X } from "lucide-react";
import { AzuroIcon } from "./Azuro";
import { auth, db } from "../lib/firebase";
import { doc, getDoc, collection, query, getDocs, orderBy, limit } from "firebase/firestore";

interface LevelData {
  id: string;
  title: string;
  authorId: string;
  createdAt: any;
}

export function Home({ onNewGame }: { onNewGame: (type: string) => void }) {
  const [userName, setUserName] = useState<string>("");
  const [levels, setLevels] = useState<LevelData[]>([]);
  const [loadingLevels, setLoadingLevels] = useState(true);
  const [showGameTypeModal, setShowGameTypeModal] = useState(false);

  const gameTypes = [
    { id: "empty", title: "Vuoto", color: "bg-slate-100", icon: Code },
    { id: "goals", title: "Get the goals", color: "bg-blue-100", icon: Play },
    { id: "quest", title: "Quest map", color: "bg-emerald-100", icon: Play },
    { id: "kungfu", title: "Kung-fu", color: "bg-red-100", icon: Play },
    { id: "maze", title: "Maze", color: "bg-purple-100", icon: Play },
    { id: "marble", title: "Marble", color: "bg-yellow-100", icon: Play },
  ];

  useEffect(() => {
    async function fetchName() {
      if (auth.currentUser) {
        try {
          const docSnap = await getDoc(doc(db, "users", auth.currentUser.uid));
          if (docSnap.exists() && docSnap.data().firstName) {
            setUserName(docSnap.data().firstName);
          } else if (auth.currentUser.displayName) {
            setUserName(auth.currentUser.displayName.split(" ")[0]);
          }
        } catch (e) {
          console.error(e);
        }
      }
    }
    
    async function fetchGames() {
      try {
        const q = query(collection(db, "levels"), orderBy("createdAt", "desc"), limit(12));
        const querySnapshot = await getDocs(q);
        const fetchedLevels: LevelData[] = [];
        querySnapshot.forEach((doc) => {
          fetchedLevels.push({ id: doc.id, ...doc.data() } as LevelData);
        });
        setLevels(fetchedLevels);
      } catch (e) {
        console.error("Error fetching games", e);
      } finally {
        setLoadingLevels(false);
      }
    }

    fetchName();
    fetchGames();
  }, []);

  return (
    <div className="w-full h-full bg-slate-100 flex flex-col font-sans overflow-y-auto">
      {/* Game Type Modal */}
      {showGameTypeModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-8 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-black text-slate-800">Che tipo di gioco vuoi creare?</h2>
              <button onClick={() => setShowGameTypeModal(false)} className="text-slate-400 hover:bg-slate-100 p-2 rounded-full transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {gameTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    onClick={() => onNewGame(type.id)}
                    className="flex flex-col items-center justify-center p-6 border-2 border-slate-100 rounded-2xl hover:border-blue-400 hover:bg-blue-50 transition-all group"
                  >
                    <div className={`w-16 h-16 ${type.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-8 h-8 text-slate-700 opacity-70" />
                    </div>
                    <span className="font-bold text-slate-700">{type.title}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Navbar */}
      <nav className="bg-white px-8 py-4 flex items-center justify-between shadow-sm sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center border-2 border-blue-400">
            <AzuroIcon className="w-6 h-6 text-blue-600" />
          </div>
          <h1 className="text-xl font-black tracking-tight text-slate-800">
            PAPIRUS<span className="text-blue-600">CRAFT</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cerca giochi..." 
              className="pl-10 pr-4 py-2 bg-slate-100 border border-slate-200 rounded-full text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-all w-64"
            />
          </div>
          <button className="p-2 text-slate-500 hover:text-slate-700 transition">
            <HelpCircle className="w-6 h-6" />
          </button>
          {auth.currentUser && (
            <button 
              onClick={() => auth.signOut()}
              className="p-2 text-slate-500 hover:text-red-600 transition"
              title="Esci"
            >
              <LogOut className="w-6 h-6" />
            </button>
          )}
        </div>
      </nav>

      <main className="flex-1 max-w-6xl w-full mx-auto p-8 flex flex-col gap-12">
        {/* Header Hero */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-12 text-white shadow-xl relative overflow-hidden flex items-center justify-between">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-white opacity-5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4"></div>
          
          <div className="relative z-10 max-w-xl">
            {userName && (
              <h2 className="text-2xl font-bold text-blue-200 mb-2">Ciao, {userName}!</h2>
            )}
            <h2 className="text-4xl font-black mb-4 tracking-tight leading-tight">Crea il tuo prossimo capolavoro.</h2>
            <p className="text-blue-100 text-lg mb-8 font-medium">Scegli tra i giochi creati dalla community oppure inizia a programmare da zero con i blocchi Blockly.</p>
            
            <div className="flex gap-4">
              <button 
                onClick={() => setShowGameTypeModal(true)}
                className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-bold py-3 px-8 rounded-full flex items-center gap-2 shadow-lg shadow-yellow-500/20 transition-all hover:-translate-y-0.5"
              >
                <Plus className="w-5 h-5" /> Nuovo Gioco
              </button>
            </div>
          </div>

          <div className="hidden lg:block relative z-10">
            <div className="w-48 h-48 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center p-6 shadow-2xl relative">
              <AzuroIcon className="w-full h-full text-white" />
              <div className="absolute -bottom-4 right-4 bg-emerald-500 text-white font-bold p-2 rounded-full shadow-lg border-2 border-white">
                <Play className="w-5 h-5 fill-current" />
              </div>
            </div>
          </div>
        </div>

        {/* Featured Games */}
        <div>
          <h3 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-2">
            Giochi In Evidenza
          </h3>
          
          {loadingLevels ? (
            <div className="flex justify-center p-12">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : levels.length === 0 ? (
            <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Play className="w-8 h-8 text-slate-400" />
              </div>
              <h4 className="text-xl font-bold text-slate-700 mb-2">Nessun gioco pubblicato al momento.</h4>
              <p className="text-slate-500">Sii il primo a creare e pubblicare la tua avventura su PapirusCraft!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {levels.map((level) => (
                <div key={level.id} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md transition-shadow cursor-pointer group">
                  <div className="aspect-video bg-slate-100 rounded-xl mb-4 relative overflow-hidden flex items-center justify-center">
                    <AzuroIcon className="w-12 h-12 text-slate-300 group-hover:scale-110 transition-transform" />
                  </div>
                  <h4 className="font-bold text-slate-800 text-lg mb-1">{level.title}</h4>
                  <div className="flex justify-between items-center mt-3 border-t border-slate-100 pt-3">
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md">Community</span>
                    <button className="text-slate-400 hover:text-emerald-500"><Play className="w-5 h-5" /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
