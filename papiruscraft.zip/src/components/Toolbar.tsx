import { MousePointer2, Pencil, Eraser, PaintBucket, Flag, Skull, Bot, Zap, Home } from "lucide-react";
import { ToolType } from "../types";
import { cn } from "../lib/utils";
import { AzuroIcon } from "./Azuro";

interface ToolbarProps {
  currentTool: ToolType;
  setTool: (t: ToolType) => void;
  gameType?: string;
  onGoHome?: () => void;
}

export function Toolbar({ currentTool, setTool, gameType = "empty", onGoHome }: ToolbarProps) {
  const allTools = [
    { id: "select", icon: MousePointer2, label: "Seleziona", color: "text-slate-600" },
    { id: "draw", icon: Pencil, label: "Disegna", color: "text-blue-600" },
    { id: "erase", icon: Eraser, label: "Cancella", color: "text-slate-500" },
    { id: "bucket", icon: PaintBucket, label: "Riempi", color: "text-indigo-600" },
    { id: "goal", icon: Flag, label: "Obiettivo", color: "text-emerald-500" },
    { id: "hazard", icon: Skull, label: "Ostacolo", color: "text-red-500" },
    { id: "azuro", icon: AzuroIcon, label: "Azuro", color: "text-blue-500" },
    { id: "ai_enemy", icon: Bot, label: "Nemico IA", color: "text-purple-600" },
    { id: "ai_powerup", icon: Zap, label: "Power-up IA", color: "text-yellow-500" },
  ];

  let tools = allTools;
  switch (gameType) {
    case 'empty':
      tools = allTools.filter(t => ['select', 'draw', 'erase', 'bucket'].includes(t.id));
      break;
    case 'goals':
      tools = allTools.filter(t => ['select', 'draw', 'erase', 'bucket', 'goal', 'hazard', 'azuro'].includes(t.id));
      break;
    case 'quest':
      tools = allTools.filter(t => ['select', 'draw', 'erase', 'bucket', 'goal', 'hazard', 'azuro', 'ai_enemy', 'ai_powerup'].includes(t.id));
      break;
    case 'kungfu':
      tools = allTools.filter(t => ['select', 'draw', 'erase', 'bucket', 'azuro', 'ai_enemy'].includes(t.id));
      break;
    case 'maze':
      tools = allTools.filter(t => ['select', 'draw', 'erase', 'bucket', 'goal', 'hazard', 'azuro'].includes(t.id));
      break;
    case 'marble':
      tools = allTools.filter(t => ['select', 'draw', 'erase', 'bucket', 'goal', 'hazard', 'azuro', 'ai_powerup'].includes(t.id));
      break;
    default:
      tools = allTools;
  }

  return (
    <div className="flex flex-col gap-4 w-20 py-6 bg-white border-r border-slate-200 h-full overflow-y-auto shrink-0 select-none items-center shadow-sm z-20">
      {onGoHome && (
        <button
          onClick={onGoHome}
          className="w-12 h-12 rounded-xl flex items-center justify-center transition-all bg-slate-100 hover:bg-slate-200 text-slate-700 mb-2 border border-slate-200"
          title="Home"
        >
          <Home className="w-6 h-6" />
        </button>
      )}

      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-2 border-2 border-blue-400">
        <AzuroIcon className="w-8 h-8 text-blue-600" />
      </div>
      
      {tools.map((t) => {
        const Icon = t.icon;
        const isActive = currentTool === t.id;
        return (
          <button
            key={t.id}
            onClick={() => setTool(t.id as ToolType)}
            className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center transition-all group relative border-2",
              isActive 
                ? "bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-500/30" 
                : "bg-blue-50/50 border-transparent text-blue-600 hover:bg-blue-50 hover:border-blue-200"
            )}
            title={t.label}
          >
            <Icon className={cn("w-6 h-6", (t as any).color && !isActive ? (t as any).color : "")} />
            
            <div className="absolute left-full ml-2 px-2 py-1 bg-slate-800 border border-slate-700 text-white text-[10px] font-bold uppercase tracking-widest rounded-md opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 shadow-lg">
              {t.label}
            </div>
          </button>
        )
      })}
    </div>
  );
}
