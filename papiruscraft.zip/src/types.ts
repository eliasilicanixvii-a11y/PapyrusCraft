import React from 'react';

export type BaseComponentProps = {
  className?: string;
  children?: React.ReactNode;
};

export type ToolType = 'select' | 'draw' | 'erase' | 'bucket' | 'goal' | 'hazard' | 'azuro' | 'ai_enemy' | 'ai_powerup';
