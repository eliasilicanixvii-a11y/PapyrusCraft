import React, { useState } from "react";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../lib/firebase";
import { ArrowRight, LogIn, UserPlus } from "lucide-react";
import { AzuroIcon } from "./Azuro";

export function AuthOverlay({ onOfflineContinue, onAuthSuccess }: { onOfflineContinue: () => void, onAuthSuccess: () => void }) {
  const [isLogin, setIsLogin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  // Registration fields
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [username, setUsername] = useState("");
  const [dob, setDob] = useState("");
  const [location, setLocation] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
        onAuthSuccess();
      } else {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        await setDoc(doc(db, "users", user.uid), {
          firstName,
          lastName,
          username,
          dob,
          location,
          createdAt: serverTimestamp()
        });
        
        onAuthSuccess();
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Si è verificato un errore");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError("");
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userDoc = await getDoc(doc(db, "users", user.uid));
      if (!userDoc.exists()) {
        const displayName = user.displayName || "";
        const nameParts = displayName.split(" ");
        await setDoc(doc(db, "users", user.uid), {
          firstName: nameParts[0] || "Utente",
          lastName: nameParts.slice(1).join(" ") || "Sconosciuto",
          username: user.email?.split("@")[0] || "user" + Math.floor(Math.random() * 1000),
          dob: "2000-01-01",
          location: "Sconosciuto",
          createdAt: serverTimestamp()
        });
      }
      onAuthSuccess();
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Si è verificato un errore con Google");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden max-w-4xl w-full flex flex-col md:flex-row">
        
        {/* Left Side: Offline / Azuro Message */}
        <div className="md:w-5/12 bg-blue-50 p-8 flex flex-col items-center justify-center border-r border-blue-100 text-center relative overflow-hidden">
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-100 rounded-full blur-3xl opacity-50"></div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-purple-100 rounded-full blur-3xl opacity-50"></div>
          
          <div className="relative z-10 flex flex-col items-center">
            {/* Azuro with hat and question mark */}
            <div className="relative mb-6">
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-10 bg-slate-800 rounded-t-lg z-10 border-b-4 border-red-500">
                <div className="absolute -bottom-2 -left-2 -right-2 h-2 bg-slate-900 rounded-full"></div>
              </div>
              <div className="w-24 h-24 bg-blue-100 border-4 border-blue-200 rounded-full flex items-center justify-center relative z-0">
                 <AzuroIcon className="w-16 h-16 text-blue-600" />
                 <div className="absolute -right-2 top-10 bg-yellow-400 text-blue-900 w-8 h-8 rounded-full flex items-center justify-center font-black shadow-lg animate-bounce">?</div>
              </div>
            </div>

            <h2 className="text-2xl font-black text-slate-800 mb-4 tracking-tight">Oops, non hai fatto il login!</h2>
            <p className="text-sm text-slate-600 mb-8 font-medium leading-relaxed">
              Vuoi giocare offline senza accesso? Puoi provare i giochi piu famosi o vedere i giochi degli altri, ma puoi creare giochi lo stesso, ma non potrai pubblicarli.
            </p>

            <button 
              onClick={onOfflineContinue}
              className="bg-white border-2 border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300 font-bold py-3 px-6 rounded-full flex items-center gap-2 transition-all shadow-sm"
            >
              Continua Offline <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Side: Auth Form */}
        <div className="md:w-7/12 p-8 lg:p-12 bg-white">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-2xl font-black text-blue-600 tracking-tight">PAPIRUS<span className="text-slate-800">CRAFT</span></h1>
            <button 
              onClick={() => { setIsLogin(!isLogin); setError(""); }}
              className="text-sm font-bold text-blue-600 hover:text-blue-700 uppercase tracking-widest"
            >
              {isLogin ? "Crea un Account" : "Hai già un account?"}
            </button>
          </div>

          <h3 className="text-xl font-bold text-slate-800 mb-6">
            {isLogin ? "Accedi per continuare" : "Registrati a Micio Inc."}
          </h3>

          <div className="mb-6">
            <button 
              type="button"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full bg-white border-2 border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300 font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
              Accedi con Google
            </button>
            <div className="flex items-center my-6">
              <div className="flex-1 border-t border-slate-200"></div>
              <span className="px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Oppure</span>
              <div className="flex-1 border-t border-slate-200"></div>
            </div>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 text-red-600 text-sm font-medium rounded-xl border border-red-100">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Nome</label>
                  <input type="text" required value={firstName} onChange={e => setFirstName(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" placeholder="Mario" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Cognome</label>
                  <input type="text" required value={lastName} onChange={e => setLastName(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" placeholder="Rossi" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Data di Nascita</label>
                  <input type="date" required value={dob} onChange={e => setDob(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium text-slate-700" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Dove Vivi</label>
                  <input type="text" required value={location} onChange={e => setLocation(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" placeholder="Milano, Italia" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Username</label>
                  <input type="text" required value={username} onChange={e => setUsername(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" placeholder="GamerMicio99" />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Email</label>
              <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" placeholder="mario@example.com" />
            </div>
            
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Password</label>
              <input type="password" required value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" placeholder="••••••••" />
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/30 mt-6 disabled:opacity-50"
            >
              {loading ? "Caricamento..." : (isLogin ? <><LogIn className="w-5 h-5" /> Accedi</> : <><UserPlus className="w-5 h-5" /> Registrati</>)}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
