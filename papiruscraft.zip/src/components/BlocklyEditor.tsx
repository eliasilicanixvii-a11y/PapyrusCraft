import React, { useEffect, useRef } from 'react';
import * as Blockly from 'blockly/core';
import 'blockly/blocks';
import * as En from 'blockly/msg/en';

Blockly.setLocale(En as any);

// Define custom custom blocks for animation and advanced mechanics
if (!Blockly.Blocks['anim_move_azuro']) {
  Blockly.defineBlocksWithJsonArray([
    {
      "type": "anim_move_azuro",
      "message0": "Muovi Azuro verso %1 di %2 pixel",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "DIR",
          "options": [
            ["Destra", "RIGHT"],
            ["Sinistra", "LEFT"],
            ["Su", "UP"],
            ["Giù", "DOWN"]
          ]
        },
        {
          "type": "field_number",
          "name": "STEPS",
          "value": 10
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 230,
      "tooltip": "Muove Azuro lungo un asse",
      "helpUrl": ""
    },
    {
      "type": "anim_color",
      "message0": "Cambia Colore Azuro in %1",
      "args0": [
        {
          "type": "field_colour",
          "name": "COL",
          "colour": "#3366ff"
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 160
    },
    {
      "type": "anim_scale",
      "message0": "Imposta Dimensione Azuro al %1 %",
      "args0": [
        {
          "type": "field_number",
          "name": "SCALE",
          "value": 150
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 200
    },
    {
      "type": "anim_bounce",
      "message0": "Effetto Rimbalzo (Bounce)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": 230
    },
    {
      "type": "anim_vibrate",
      "message0": "Effetto Vibrazione (Vibration)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": 230
    },
    {
      "type": "asp_background",
      "message0": "Cambia Sfondo in %1 (Background)",
      "args0": [
        {
          "type": "field_colour",
          "name": "COL",
          "colour": "#ffffff"
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 160
    },
    {
      "type": "asp_hazard",
      "message0": "Rendi Ostacolo (Hazard in Bop for destroy)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": 160
    },
    {
      "type": "asp_projectiles",
      "message0": "Spara Proiettili (Projectiles)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": 160
    },
    {
      "type": "avatar_teleport",
      "message0": "Teletrasporta Avatar (Teleportal) a X:%1 Y:%2",
      "args0": [
        {
          "type": "field_number",
          "name": "X",
          "value": 0
        },
        {
          "type": "field_number",
          "name": "Y",
          "value": 0
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 200
    },
    {
      "type": "avatar_shrink",
      "message0": "Rimpicciolisci Avatar (Shrink)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": 200
    },
    {
      "type": "func_bgm",
      "message0": "Musica di Sottofondo (Background music) %1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "TRACK",
          "options": [
            ["Avventura", "ADV"],
            ["Azione", "ACT"],
            ["Calma", "CALM"]
          ]
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 290
    },
    {
      "type": "func_sfx",
      "message0": "Effetto Sonoro (Sound effect) %1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "SFX",
          "options": [
            ["Salto", "JUMP"],
            ["Esplosione", "EXPL"]
          ]
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 290
    },
    {
      "type": "func_flip_gravity",
      "message0": "Inverti Gravità (Flip gravity)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": 290
    },
    {
      "type": "func_speed",
      "message0": "Cambia Velocità Avatar (Change speed) a %1",
      "args0": [
        {
          "type": "field_number",
          "name": "SPEED",
          "value": 5
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 290
    },
    {
      "type": "anim_frame",
      "message0": "Keyframe (Fotogramma Animazione) %1 %2",
      "args0": [
        {
          "type": "input_dummy"
        },
        {
          "type": "input_statement",
          "name": "FRAME_ACTIONS"
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": 290,
      "tooltip": "Definisce un fotogramma nella timeline di Azuro"
    },
    {
      "type": "event_on_start",
      "message0": "Quando il livello inizia %1 %2",
      "args0": [
        {
          "type": "input_dummy"
        },
        {
          "type": "input_statement",
          "name": "START_ACTIONS"
        }
      ],
      "colour": 65
    }
  ]);
}

export function BlocklyEditor({ onClose }: { onClose: () => void }) {
  const blocklyDiv = useRef<HTMLDivElement>(null);
  const workspace = useRef<Blockly.WorkspaceSvg>();

  useEffect(() => {
    if (blocklyDiv.current && !workspace.current) {
      workspace.current = Blockly.inject(blocklyDiv.current, {
        toolbox: {
          kind: 'categoryToolbox',
          contents: [
            {
              kind: 'category',
              name: 'Animazioni Azuro',
              colour: '290',
              contents: [
                { kind: 'block', type: 'event_on_start' },
                { kind: 'block', type: 'anim_frame' },
                { kind: 'block', type: 'anim_move_azuro' },
                { kind: 'block', type: 'anim_color' },
                { kind: 'block', type: 'anim_scale' }
              ]
            },
            {
              kind: 'category',
              name: 'Movimento',
              colour: '230',
              contents: [
                { kind: 'block', type: 'anim_move_azuro' },
                { kind: 'block', type: 'anim_bounce' },
                { kind: 'block', type: 'anim_vibrate' }
              ]
            },
            {
              kind: 'category',
              name: 'Aspetto',
              colour: '160',
              contents: [
                { kind: 'block', type: 'asp_background' },
                { kind: 'block', type: 'anim_color' },
                { kind: 'block', type: 'asp_hazard' },
                { kind: 'block', type: 'asp_projectiles' }
              ]
            },
            {
              kind: 'category',
              name: 'Avatar',
              colour: '200',
              contents: [
                { kind: 'block', type: 'avatar_teleport' },
                { kind: 'block', type: 'avatar_shrink' }
              ]
            },
            {
              kind: 'category',
              name: 'Funzioni',
              colour: '290',
              contents: [
                { kind: 'block', type: 'func_bgm' },
                { kind: 'block', type: 'func_sfx' },
                { kind: 'block', type: 'func_flip_gravity' },
                { kind: 'block', type: 'func_speed' }
              ]
            },
            {
              kind: 'category',
              name: 'Logica Base',
              colour: '210',
              contents: [
                { kind: 'block', type: 'controls_if' },
                { kind: 'block', type: 'controls_repeat_ext' },
                { kind: 'block', type: 'logic_compare' },
                { kind: 'block', type: 'math_number' },
                { kind: 'block', type: 'math_arithmetic' },
                { kind: 'block', type: 'text' },
                { kind: 'block', type: 'text_print' }
              ]
            }
          ]
        },
      });
    }

    return () => {
      // Clean up blockly if necessary, though typical React mounts don't destroy often
      // workspace.current?.dispose();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-slate-200/50 backdrop-blur-sm flex items-center justify-center p-8">
      <div className="bg-slate-900/95 border-4 border-orange-400 w-full h-full max-w-6xl max-h-screen rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        <div className="flex justify-between items-center px-6 py-4 border-b border-slate-700/50 relative">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-400 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <h2 className="text-[12px] font-bold text-orange-400 ml-4 font-mono tracking-widest uppercase">
              Blockly: Azuro_Logic
            </h2>
          </div>
          <div className="flex gap-4">
            <button className="bg-orange-500 hover:bg-orange-400 text-white px-6 py-1.5 rounded-full font-bold text-sm transition-colors uppercase">
              Salva Logica
            </button>
            <button 
              onClick={onClose}
              className="bg-white/10 hover:bg-white/20 text-white px-6 py-1.5 rounded-full font-bold text-sm border border-white/20 transition-colors uppercase"
            >
              Chiudi
            </button>
          </div>
        </div>
        <div className="flex-1 relative">
          <div ref={blocklyDiv} className="absolute inset-0" />
        </div>
      </div>
    </div>
  );
}
