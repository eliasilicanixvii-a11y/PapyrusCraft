import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI
  let ai: GoogleGenAI | null = null;
  const getAI = () => {
    if (!ai) {
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        throw new Error("GEMINI_API_KEY environment variable is required");
      }
      ai = new GoogleGenAI({ apiKey: key });
    }
    return ai;
  };

  // API Routes
  app.post("/api/generate-game", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Il prompt è obbligatorio." });
      }

      const aiClient = getAI();
      const response = await aiClient.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Sei l'assistente IA di "PapirusCraft", un editor di giochi desktop avanzato.
L'utente ti ha richiesto di generare delle idee, logiche o elementi per un gioco personalizzato basato su questo prompt: "${prompt}".
Rispondi con una breve struttura di gioco (obiettivi, ostacoli, power-up) e alcune linee guida su come impostarlo nell'editor. Rispondi in italiano in modo amichevole come se fossi il tuo creatore, Micio Inc. Menzione "Azuro il Gatto Blu" se ha senso. Mantienilo breve.`,
      });

      res.json({ result: response.text });
    } catch (e: any) {
      console.error("AI Error:", e);
      res.status(500).json({ error: e.message || "Si è verificato un errore." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production serving
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
