import { useState, useRef, useEffect } from "react";
import { Sparkles, Send, Loader2 } from "lucide-react";
import { AzuroIcon } from "./Azuro";

export function AIWizard() {
  const [isOpen, setIsOpen] = useState(true);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'ai', content: string}[]>([
    {
      role: 'ai',
      content: "Miao! Sono Azuro il Gatto Blu, l'assistente IA di Micio Inc. Dimmi che gioco vuoi creare e io ti darò le idee e la struttura giusta per PapirusCraft!"
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleGenerate = async () => {
    if (!prompt.trim() || loading) return;

    const userMessage = prompt;
    setPrompt("");
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const res = await fetch("/api/generate-game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: userMessage })
      });

      const data = await res.json();
      
      setMessages(prev => [...prev, { 
        role: 'ai', 
        content: data.result || data.error || "Miao... il cervello di Micio Inc. è confuso..." 
      }]);
    } catch (e) {
      setMessages(prev => [...prev, { 
        role: 'ai', 
        content: "Miao... Errore di connessione." 
      }]);
    }

    setLoading(false);
  };

  if (!isOpen) {
    return (
      <div className="absolute bottom-6 right-6 z-40">
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-blue-600 hover:bg-blue-500 text-white p-4 rounded-full shadow-lg shadow-blue-500/30 flex items-center justify-center transition-transform hover:scale-110 border-4 border-white"
        >
          <AzuroIcon className="w-8 h-8 text-white" />
        </button>
      </div>
    );
  }

  return (
    <div className="absolute bottom-6 right-6 w-96 max-h-[600px] flex flex-col bg-white border border-slate-200 shadow-[0_8px_30px_rgb(0,0,0,0.12)] rounded-2xl z-40 overflow-hidden">
      <div className="flex bg-blue-600 px-4 py-3 items-center justify-between shadow-md">
        <div className="flex items-center gap-2 text-white font-bold tracking-tight">
          <AzuroIcon className="w-6 h-6 text-white" />
          <span>Generatore IA Micio Inc.</span>
        </div>
        <button 
          onClick={() => setIsOpen(false)}
          className="text-blue-200 hover:text-white"
        >
          Chiudi
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[400px] bg-slate-50">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {m.role === 'ai' && (
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center shrink-0 border border-blue-200">
                <AzuroIcon className="w-5 h-5" />
              </div>
            )}
            <div className={`p-3 text-sm shadow-sm ${
              m.role === 'user' 
                ? 'bg-blue-600 text-white rounded-2xl rounded-tr-sm' 
                : 'bg-white border border-slate-200 text-slate-700 rounded-2xl rounded-tl-sm'
            }`}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3 justify-start">
             <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center shrink-0 border border-blue-200">
                <AzuroIcon className="w-5 h-5" />
              </div>
              <div className="p-3 bg-white border border-slate-200 text-slate-700 rounded-2xl rounded-tl-sm flex items-center shadow-sm">
                <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-slate-200 bg-slate-100 flex flex-col gap-3">
        <div className="flex gap-2">
          <input 
            type="text" 
            className="flex-1 bg-white border border-slate-300 rounded-full px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all font-medium placeholder-slate-400 shadow-inner"
            placeholder="Chiedi ad Azuro un gioco o un elemento IA..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
            disabled={loading}
          />
          <button 
            onClick={handleGenerate}
            disabled={loading || !prompt.trim()}
            className="bg-blue-600 disabled:opacity-50 hover:bg-blue-700 text-white p-2 px-4 rounded-full shadow-md transition-colors flex items-center justify-center"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        
        <div className="text-[10px] text-slate-500 font-medium">
          <p className="mb-1 font-bold text-slate-700 uppercase tracking-wider">Integrazione Avanzata Elementi IA</p>
          <p>
            Puoi utilizzare i tool <span className="font-bold text-purple-600">Nemico IA</span> e <span className="font-bold text-yellow-500">Power-up IA</span> dalla barra degli strumenti per posizionare entità dinamiche. 
            Questi elementi verranno generati e bilanciati automaticamente dall'IA in base al contesto del livello (es. descrivi il tema sopra e l'IA adatterà la logica, la grafica e i comportamenti dei nemici). In futuro potrai selezionare una di queste entità ed espanderne la logica su Blockly.
          </p>
        </div>
      </div>
    </div>
  )
}

