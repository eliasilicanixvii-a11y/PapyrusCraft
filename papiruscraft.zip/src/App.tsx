import React, { useState, useEffect } from "react";
import { Toolbar } from "./components/Toolbar";
import { Canvas } from "./components/Canvas";
import { AIWizard } from "./components/AIWizard";
import { BlocklyEditor } from "./components/BlocklyEditor";
import { AuthOverlay } from "./components/AuthOverlay";
import { Home } from "./components/Home";
import { ToolType } from "./types";
import { auth } from "./lib/firebase";
import { onAuthStateChanged, User } from "firebase/auth";

type ViewType = 'home' | 'editor';

export default function App() {
  const [currentTool, setCurrentTool] = useState<ToolType>('draw');
  const [showBlockly, setShowBlockly] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);
  const [view, setView] = useState<ViewType>('home');
  const [gameType, setGameType] = useState<string>('empty');

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) {
        setOfflineMode(false);
      }
      setAuthChecked(true);
    });
    return () => unsub();
  }, []);

  if (!authChecked) {
    return <div className="w-screen h-screen bg-slate-100 flex items-center justify-center"><div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div></div>;
  }

  return (
    <div className="w-screen h-screen overflow-hidden flex bg-slate-100 font-sans">
      {!user && !offlineMode && (
        <AuthOverlay onOfflineContinue={() => setOfflineMode(true)} onAuthSuccess={() => setOfflineMode(false)} />
      )}
      
      {view === 'home' ? (
        <Home onNewGame={(type) => {
          console.log("Game type selected:", type);
          setGameType(type);
          setView('editor');
        }} />
      ) : (
        <>
          <Toolbar currentTool={currentTool} setTool={setCurrentTool} gameType={gameType} onGoHome={() => {
            if (window.confirm("Vuoi uscire dalla pagina? Le modifiche non sono salvate")) {
              setView('home');
            }
          }} />
          
          <main className="flex-1 relative flex flex-col bg-slate-200">
            <Canvas 
              currentTool={currentTool} 
              gameType={gameType}
              onOpenBlockly={() => setShowBlockly(true)} 
              onGoHome={() => {
                if (window.confirm("Vuoi uscire dalla pagina? Le modifiche non sono salvate")) {
                  setView('home');
                }
              }}
            />
            <AIWizard />
          </main>

          {showBlockly && (
            <BlocklyEditor onClose={() => setShowBlockly(false)} />
          )}
        </>
      )}
    </div>
  );
}
