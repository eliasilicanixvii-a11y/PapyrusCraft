import React, { useState, useRef, useEffect } from "react";
import { ToolType } from "../types";
import { cn } from "../lib/utils";
import { Play, Code, Square, Download, Upload, CloudUpload, X, RefreshCcw, Home, Edit2 } from "lucide-react";
import { AzuroIcon } from "./Azuro";
import { auth, db } from "../lib/firebase";
import { doc, setDoc, collection, serverTimestamp } from "firebase/firestore";

interface CanvasProps {
  currentTool: ToolType;
  gameType: string;
  onOpenBlockly: () => void;
  onGoHome?: () => void;
}

type Cell = { x: number, y: number, type: ToolType | 'empty' };

export function Canvas({ currentTool, gameType, onOpenBlockly, onGoHome }: CanvasProps) {
  const [grid, setGrid] = useState<Cell[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingPlay, setIsLoadingPlay] = useState(false);
  const [azuroPos, setAzuroPos] = useState<{x: number, y: number} | null>(null);
  const [gameResult, setGameResult] = useState<'none' | 'win' | 'lose'>('none');
  
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [publishTitle, setPublishTitle] = useState("");
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishMessage, setPublishMessage] = useState("");
  
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const jumpRef = useRef({ remaining: 0, isJumping: false });
  
  const width = 30;
  const height = 20;

  useEffect(() => {
    // Initialize empty grid
    const initialGrid = [];
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        initialGrid.push({ x, y, type: 'empty' as const });
      }
    }
    setGrid(initialGrid);
  }, []);

  // Platformer Gravity Loop
  useEffect(() => {
    if (!isPlaying || gameResult !== 'none') return;
    
    let interval: any;
    if (['goals', 'kungfu'].includes(gameType)) {
      interval = setInterval(() => {
         setAzuroPos(prev => {
            if (!prev) return prev;
            
            let newY = prev.y;
            let newX = prev.x;

            if (jumpRef.current.remaining > 0) {
              newY = Math.max(0, prev.y - 1);
              jumpRef.current.remaining -= 1;
            } else {
              newY = prev.y + 1;
            }

            if (newY >= height) {
              setTimeout(() => setGameResult('lose'), 50);
              return prev;
            }

            if (newY === prev.y && newX === prev.x) return prev;

            const targetCell = grid.find(c => c.x === newX && c.y === newY);
            if (targetCell && targetCell.type === 'goal') {
              setTimeout(() => setGameResult('win'), 50);
            } else if (targetCell && (targetCell.type === 'hazard' || targetCell.type === 'ai_enemy')) {
              setTimeout(() => setGameResult('lose'), 50);
            }

            const obstacleTypes = ['draw', 'bucket'];
            if (targetCell && obstacleTypes.includes(targetCell.type)) {
               if (jumpRef.current.remaining > 0) {
                 jumpRef.current.remaining = 0; // stop jump on head bonk
               }
               return prev; // Blocked by floor/ceiling
            }

            return { x: newX, y: newY };
         });
      }, 150);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, grid, height, gameType, gameResult]);

  // Keyboard Movement
  useEffect(() => {
    if (!isPlaying) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      e.preventDefault();
      if (gameResult !== 'none') return;

      setAzuroPos(prev => {
        if (!prev) return prev;
        let newX = prev.x;
        let newY = prev.y;

        const isPlatformer = ['goals', 'kungfu'].includes(gameType);

        if (isPlatformer) {
          if (e.key === 'ArrowUp' || e.key === 'w') {
            const belowCell = grid.find(c => c.x === prev.x && c.y === prev.y + 1);
            const isGrounded = belowCell && ['draw', 'bucket'].includes(belowCell.type);
            if (isGrounded) {
               jumpRef.current.remaining = 3;
            }
          }
          if (e.key === 'ArrowLeft' || e.key === 'a') newX = Math.max(0, prev.x - 1);
          if (e.key === 'ArrowRight' || e.key === 'd') newX = Math.min(width - 1, prev.x + 1);
        } else {
          if (e.key === 'ArrowUp' || e.key === 'w') newY = Math.max(0, prev.y - 1);
          if (e.key === 'ArrowDown' || e.key === 's') newY = Math.min(height - 1, prev.y + 1);
          if (e.key === 'ArrowLeft' || e.key === 'a') newX = Math.max(0, prev.x - 1);
          if (e.key === 'ArrowRight' || e.key === 'd') newX = Math.min(width - 1, prev.x + 1);
        }

        if (newX === prev.x && newY === prev.y) return prev;

        const targetCell = grid.find(c => c.x === newX && c.y === newY);
        
        if (targetCell && targetCell.type === 'goal') {
          setTimeout(() => setGameResult('win'), 50);
        } else if (targetCell && (targetCell.type === 'hazard' || targetCell.type === 'ai_enemy')) {
          setTimeout(() => setGameResult('lose'), 50);
        }

        const obstacleTypes = ['draw', 'bucket'];
        if (targetCell && obstacleTypes.includes(targetCell.type)) {
          return prev; // Blocked
        }

        return { x: newX, y: newY };
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, grid, width, height, gameResult, gameType]);

  const handleInteract = (x: number, y: number) => {
    if (isPlaying) return;
    if (currentTool === 'select') return;
    
    setGrid(prev => prev.map(cell => {
      if (cell.x === x && cell.y === y) {
        return { ...cell, type: currentTool === 'erase' ? 'empty' : currentTool };
      }
      return cell;
    }));
  };

  const togglePlay = () => {
    if (!isPlaying) {
      // Find Azuro to start the game
      const azuro = grid.find(c => c.type === 'azuro');
      
      if (!azuro) {
        window.alert("Devi posizionare Azuro per iniziare la partita!");
        return;
      }

      const goal = grid.find(c => c.type === 'goal');
      const enemy = grid.find(c => c.type === 'ai_enemy');

      if (gameType === 'kungfu') {
        if (!enemy) {
          window.alert("In modalità Kung-fu non serve il goal ma devi posizionare un avversario (IA)!");
          return;
        }
      } else if (gameType !== 'empty') {
        if (!goal) {
          window.alert("Errore : Non c'è nessun avatar o goal, il gioco non partirebbe se non gli metti avatar o goal, quuindi mettilo");
          return;
        }
      }
      
      setIsLoadingPlay(true);
      setTimeout(() => {
        setIsLoadingPlay(false);
        setAzuroPos({ x: azuro.x, y: azuro.y });
        setGameResult('none');
        setIsPlaying(true);
      }, 2000);
      return;
    } else {
      setAzuroPos(null);
      setGameResult('none');
    }
    setIsPlaying(!isPlaying);
  };

  const saveLevel = () => {
    const data = JSON.stringify(grid);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "level.papyrus";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    if (!publishTitle.trim()) return;

    setIsPublishing(true);
    setPublishMessage("");

    try {
      const levelRef = doc(collection(db, "levels"));
      const gridData = JSON.stringify(grid);
      
      await setDoc(levelRef, {
        title: publishTitle.trim(),
        authorId: auth.currentUser.uid,
        gridData: gridData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      setPublishMessage("Pubblicato con successo!");
      setTimeout(() => setShowPublishModal(false), 2000);
    } catch (err: any) {
      console.error(err);
      setPublishMessage("Errore durante la pubblicazione. Controlla la connessione.");
    } finally {
      setIsPublishing(false);
    }
  };

  const loadLevel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json') && !file.name.endsWith('.js') && !file.name.endsWith('.papyrus')) {
     alert("PapyrusCraft supporta SOLO i file .json, .js e .papyrus");
     return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const loadedGrid = JSON.parse(event.target?.result as string);
        if (Array.isArray(loadedGrid)) {
          setGrid(loadedGrid);
        }
      } catch (err) {
        alert("Errore durante il caricamento del file!");
      }
    };
    reader.readAsText(file);
    // reseta l'input cosi da far poter ricaricare lo stesso file
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const getCellColor = (type: ToolType | 'empty') => {
    switch (type) {
      case 'draw': return 'bg-slate-400';
      case 'bucket': return 'bg-slate-500';
      case 'goal': return 'bg-emerald-500';
      case 'hazard': return 'bg-red-500';
      case 'azuro': return 'bg-blue-600 rounded-lg shadow-md';
      case 'ai_enemy': return 'bg-purple-600 border-2 border-purple-800 rounded-sm';
      case 'ai_powerup': return 'bg-yellow-400 rounded-full animate-pulse shadow-[0_0_10px_rgba(250,204,21,0.8)]';
      case 'empty': default: return 'bg-transparent';
    }
  };

  return (
    <div className="flex-1 bg-slate-200 flex flex-col items-center justify-center relative p-8">
      
      <style>{`
        @keyframes rainbow {
          0% { background-color: #ff0000; }
          14% { background-color: #ff7f00; }
          28% { background-color: #ffff00; }
          42% { background-color: #00ff00; }
          57% { background-color: #0000ff; }
          71% { background-color: #4b0082; }
          85% { background-color: #9400d3; }
          100% { background-color: #ff0000; }
        }
      `}</style>

      {/* Loading Overlay */}
      {isLoadingPlay && (
        <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center animate-in fade-in duration-300" style={{ animation: 'rainbow 2s linear infinite' }}>
          <h2 className="text-7xl font-black text-white drop-shadow-2xl tracking-tighter animate-pulse">Loading...</h2>
        </div>
      )}

      {/* Game Result Fullscreen Overlay */}
      {gameResult !== 'none' && (
        <div className={`fixed inset-0 z-[100] ${gameResult === 'win' ? 'bg-emerald-500' : 'bg-red-500'} flex flex-col items-center justify-center animate-in fade-in zoom-in slide-in-from-bottom-8 duration-500`}>
          <h2 className="text-7xl font-black text-white mb-12 drop-shadow-xl tracking-tighter animate-in fade-in zoom-in duration-700 delay-150">
            {gameResult === 'win' ? 'YOU WIN!' : 'GAME OVER'}
          </h2>
          <div className="flex items-center gap-6 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            <button 
              onClick={() => {
                const azuro = grid.find(c => c.type === 'azuro');
                if (azuro) setAzuroPos({ x: azuro.x, y: azuro.y });
                setGameResult('none');
              }}
              className="flex flex-col items-center gap-3 text-white hover:scale-110 transition-transform group"
            >
              <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center group-hover:bg-white/30 backdrop-blur-sm shadow-xl">
                <RefreshCcw className="w-10 h-10" />
              </div>
              <span className={`font-bold tracking-widest text-sm uppercase ${gameResult === 'win' ? 'text-emerald-100' : 'text-red-100'}`}>Riprova</span>
            </button>

            <button 
              onClick={() => {
                if (onGoHome) onGoHome();
              }}
              className="flex flex-col items-center gap-3 text-white hover:scale-110 transition-transform group"
            >
              <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center group-hover:bg-white/30 backdrop-blur-sm shadow-xl">
                <Home className="w-10 h-10" />
              </div>
              <span className={`font-bold tracking-widest text-sm uppercase ${gameResult === 'win' ? 'text-emerald-100' : 'text-red-100'}`}>Home</span>
            </button>

            <button 
              onClick={() => {
                setGameResult('none');
                setIsPlaying(false);
              }}
              className="flex flex-col items-center gap-3 text-white hover:scale-110 transition-transform group"
            >
              <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center group-hover:bg-white/30 backdrop-blur-sm shadow-xl">
                <Edit2 className="w-10 h-10" />
              </div>
              <span className={`font-bold tracking-widest text-sm uppercase ${gameResult === 'win' ? 'text-emerald-100' : 'text-red-100'}`}>Modifica</span>
            </button>
          </div>
        </div>
      )}

      {/* Publish Modal Overylay */}
      {showPublishModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-black text-slate-800">Pubblica Gioco</h2>
              <button 
                onClick={() => setShowPublishModal(false)} 
                className="text-slate-400 hover:bg-slate-100 p-2 rounded-full transition-colors"
                disabled={isPublishing}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {publishMessage && (
              <div className={`p-4 mb-6 rounded-xl font-bold text-sm ${publishMessage.includes('Errore') ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'}`}>
                {publishMessage}
              </div>
            )}

            <form onSubmit={handlePublish}>
              <div className="mb-6">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Titolo del Gioco</label>
                <input 
                  type="text" 
                  value={publishTitle}
                  onChange={(e) => setPublishTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all font-medium placeholder-slate-400" 
                  placeholder="La mia avventura con Azuro!" 
                  required
                  maxLength={100}
                />
              </div>

              <div className="mb-6 p-4 bg-blue-50 text-blue-800 text-sm font-medium rounded-xl border border-blue-100 flex items-start gap-3">
                <CloudUpload className="w-5 h-5 shrink-0 mt-0.5" />
                <p>Al momento la thumbnail viene stilata automaticamente! Altri utenti vedranno il tuo livello nella Home.</p>
              </div>

              <button 
                type="submit" 
                disabled={isPublishing || !publishTitle.trim()}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/30 disabled:opacity-50"
              >
                {isPublishing ? 'Pubblicazione...' : 'Pubblica Livello'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Top Header / Actions Area */}
      <div className="absolute top-6 left-6 right-6 flex justify-between items-center z-10">
        <div className="text-slate-800">
          <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
            PAPIRUS<span className="text-blue-600">CRAFT</span>
          </h1>
          <p className="text-sm text-slate-500 font-mono">No limits. Just create.</p>
        </div>
        
        <div className="flex gap-3">
          <input 
            type="file" 
            accept=".json,.js,.papyrus" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={loadLevel} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isPlaying}
            className="flex items-center gap-2 bg-white disabled:opacity-50 text-slate-600 border border-slate-300 hover:bg-slate-50 px-4 py-2 rounded-full transition-all font-bold text-sm shadow-sm"
          >
            <Upload className="w-4 h-4" />
            Carica Gioco
          </button>
          
          <button 
            onClick={saveLevel}
            disabled={isPlaying}
            className="flex items-center gap-2 bg-white disabled:opacity-50 text-slate-600 border border-slate-300 hover:bg-slate-50 px-4 py-2 rounded-full transition-all font-bold text-sm shadow-sm"
          >
            <Download className="w-4 h-4" />
            Salva
          </button>

          <div className="w-px h-8 bg-slate-300 mx-1 border-hidden my-auto" />

          {auth.currentUser && (
            <button 
              onClick={() => setShowPublishModal(true)}
              disabled={isPlaying}
              className="flex items-center gap-2 bg-blue-100 disabled:opacity-50 text-blue-700 border-2 border-blue-200 hover:bg-blue-200 px-4 py-2 rounded-full transition-all font-bold text-sm uppercase tracking-wider"
            >
              <CloudUpload className="w-4 h-4" />
              Pubblica
            </button>
          )}

          {['quest', 'marble'].includes(gameType) && (
            <button 
              onClick={onOpenBlockly}
              disabled={isPlaying}
              className="flex items-center gap-2 bg-orange-100 disabled:opacity-50 text-orange-600 border-2 border-orange-200 hover:bg-orange-200 px-4 py-2 rounded-full transition-all font-bold text-sm uppercase tracking-wider"
            >
              <Code className="w-4 h-4" />
              Apri Blockly
            </button>
          )}
          
          <button 
            onClick={togglePlay}
            className={cn(
              "flex items-center gap-2 shadow-lg px-6 py-2 rounded-full transition-all font-bold text-sm hover:-translate-y-0.5",
              isPlaying 
                ? "bg-red-500 hover:bg-red-600 text-white shadow-red-500/20" 
                : "bg-yellow-400 hover:bg-yellow-500 text-blue-900 shadow-yellow-500/20"
            )}
          >
            {isPlaying ? (
              <>
                <Square className="w-5 h-5 fill-current" />
                STOP TEST
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" />
                PLAY TEST
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grid Canvas */}
      <div 
        ref={containerRef}
        className="w-full max-w-5xl aspect-[3/2] bg-white rounded-3xl shadow-inner border-8 border-slate-300 relative grid overflow-hidden select-none touch-none"
        style={{
          gridTemplateColumns: `repeat(${width}, minmax(0, 1fr))`,
          gridTemplateRows: `repeat(${height}, minmax(0, 1fr))`,
          cursor: isPlaying ? 'default' : (currentTool === 'select' ? 'default' : 'crosshair')
        }}
        onPointerDown={() => setIsDrawing(true)}
        onPointerUp={() => setIsDrawing(false)}
        onPointerLeave={() => setIsDrawing(false)}
      >
        <div className="absolute inset-0 pointer-events-none grid"
             style={{
               gridTemplateColumns: `repeat(${width}, minmax(0, 1fr))`,
               gridTemplateRows: `repeat(${height}, minmax(0, 1fr))`,
             }}>
          {/* Grid lines */}
          {Array.from({ length: width * height }).map((_, i) => (
            <div key={`grid-${i}`} className="border-[0.5px] border-slate-200" />
          ))}
        </div>

        {grid.map((cell) => {
          // In play mode, hide the static Azuro
          const isAzuroSlot = cell.type === 'azuro';
          const typeToRender = isPlaying && isAzuroSlot ? 'empty' : cell.type;
          
          return (
            <div
              key={`${cell.x}-${cell.y}`}
              className={cn("w-full h-full relative transition-colors duration-75", getCellColor(typeToRender))}
              onPointerDown={() => handleInteract(cell.x, cell.y)}
              onPointerEnter={() => isDrawing && handleInteract(cell.x, cell.y)}
            >
              {typeToRender === 'azuro' && (
                <div className="absolute inset-0 flex items-center justify-center p-0.5">
                  <AzuroIcon className="w-full h-full text-white" />
                </div>
              )}
              {typeToRender === 'ai_enemy' && (
                <div className="absolute inset-0 flex items-center justify-center font-bold text-xs text-white">IA</div>
              )}
            </div>
          );
        })}

        {/* Dynamic Azuro Player */}
        {isPlaying && azuroPos && (
          <div 
            className="absolute transition-all duration-100 pointer-events-none bg-blue-600 rounded-lg shadow-xl ring-2 ring-blue-300 z-20 flex items-center justify-center p-0.5"
            style={{
              width: `${100 / width}%`,
              height: `${100 / height}%`,
              left: `${(azuroPos.x / width) * 100}%`,
              top: `${(azuroPos.y / height) * 100}%`
            }}
          >
            <AzuroIcon className="w-full h-full text-white" />
          </div>
        )}
      </div>
    </div>
  );
}
